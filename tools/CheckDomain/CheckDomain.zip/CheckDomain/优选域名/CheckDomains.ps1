﻿Write-Host "CheckDomain | Cloudflare EDT 导航 https://bestcf.pages.dev" -ForegroundColor Cyan

$InputFile = "Domain-Data-CF.csv"
$BestOutputFile = "Domain-Latency.txt"
$MaxThreads = 100           
$TimeoutMs = 2500

$TestLimit = 1000   # 设定的测试总量
$ResultLimit = 50   # 最终输出的最多数据条数

# 严格保留原始初始化逻辑
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
[Net.ServicePointManager]::DefaultConnectionLimit = 1000
[Net.ServicePointManager]::CheckCertificateRevocationList = $false

Stop-Process -Name "curl" -ErrorAction SilentlyContinue
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom

if (-not (Test-Path $InputFile)) { Write-Host "找不到 $InputFile" -ForegroundColor Red; exit }

$AbsInput = (Resolve-Path $InputFile).Path
$AbsBestOutput = (Join-Path (Get-Location) $BestOutputFile)

[System.IO.File]::WriteAllText($AbsBestOutput, "", $Utf8NoBom)

$TotalLines = [System.IO.File]::ReadAllLines($AbsInput) | Where-Object { $_.Trim() }
$TotalCount = $TotalLines.Count
$FinalTestCount = [Math]::Min($TestLimit, $TotalCount)
$RandomLines = $TotalLines | Get-Random -Count $FinalTestCount

$ISS = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
$Pool = [RunspaceFactory]::CreateRunspacePool(1, $MaxThreads, $ISS, $Host)
$Pool.Open()

$FinalResults = New-Object System.Collections.ArrayList
$Jobs = New-Object System.Collections.Generic.List[hashtable]

$ProcessedCount = 0
$SuccessCount = 0

$ScriptBlock = {
    param($d, $t)
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [Net.ServicePointManager]::CheckCertificateRevocationList = $false
    [Net.ServicePointManager]::DefaultConnectionLimit = 1000
    $url = "https://$d/cdn-cgi/trace"
    $isAvailable = $false
    $httpsTime = 0
    try {
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        $request = [System.Net.HttpWebRequest]::Create($url)
        $request.Proxy = $null; $request.Timeout = $t; $request.KeepAlive = $true 
        $response = $request.GetResponse()
        $sw.Stop(); $httpsTime = $sw.ElapsedMilliseconds 
        $stream = $response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream)
        $content = $reader.ReadToEnd() 
        if ($content.Contains("colo=")) { $isAvailable = $true }
        $response.Close(); $reader.Dispose()
    } catch { $isAvailable = $false }

    if ($isAvailable) {
        $totalTcpTime = 0; $tcpSuccess = 0
        for ($i = 0; $i -lt 3; $i++) {
            $tcpSw = [System.Diagnostics.Stopwatch]::StartNew()
            $tcpClient = New-Object System.Net.Sockets.TcpClient
            try {
                $ar = $tcpClient.BeginConnect($d, 443, $null, $null)
                if ($ar.AsyncWaitHandle.WaitOne(1000) -and $tcpClient.Connected) {
                    $tcpSw.Stop(); $totalTcpTime += $tcpSw.ElapsedMilliseconds; $tcpSuccess++
                }
            } catch { }
            finally { if ($tcpClient) { $tcpClient.Close(); $tcpClient.Dispose() } }
            if ($i -lt 2) { Start-Sleep -Milliseconds 15 }
        }
        if ($tcpSuccess -gt 0) {
            $finalLatency = [Math]::Round($totalTcpTime / $tcpSuccess)
            return @{ "domain" = $d; "success" = $true; "time" = $finalLatency }
        }
    }
    return @{ "domain" = $d; "success" = $false }
}

Write-Host "开始检测: 随机抽取 $FinalTestCount 个域名..." -ForegroundColor Cyan

foreach ($line in $RandomLines) {
    $d = $line.Trim(); if ([string]::IsNullOrWhiteSpace($d)) { continue }
    
    $PS = [powershell]::Create().AddScript($ScriptBlock).AddArgument($d).AddArgument($TimeoutMs)
    $PS.RunspacePool = $Pool
    $Jobs.Add(@{ "Instance" = $PS; "Result" = $PS.BeginInvoke() })

    while ($Jobs.Count -ge $MaxThreads) {
        $Finished = $Jobs | Where-Object { $_.Result.IsCompleted }
        foreach ($Job in $Finished) {
            $output = $Job.Instance.EndInvoke($Job.Result)
            $ProcessedCount++
            if ($output.success) {
                $SuccessCount++
                $null = $FinalResults.Add($output)
            }
            $Job.Instance.Dispose(); $Jobs.Remove($Job) > $null
        }
        $Percent = "{0:P2}" -f ($ProcessedCount / $FinalTestCount)
        Write-Host -NoNewline "`r检测进度: $ProcessedCount/$FinalTestCount ($Percent) | 有效域名: $SuccessCount    " -ForegroundColor Yellow
        if ($Finished.Count -eq 0) { Start-Sleep -Milliseconds 50 }
    }
}

while ($Jobs.Count -gt 0) {
    $Finished = $Jobs | Where-Object { $_.Result.IsCompleted }
    foreach ($Job in $Finished) {
        $output = $Job.Instance.EndInvoke($Job.Result)
        $ProcessedCount++
        if ($output.success) {
            $SuccessCount++
            $null = $FinalResults.Add($output)
        }
        $Job.Instance.Dispose(); $Jobs.Remove($Job) > $null
    }
    $Percent = "{0:P2}" -f ($ProcessedCount / $FinalTestCount)
    Write-Host -NoNewline "`r最终结果: $ProcessedCount/$FinalTestCount ($Percent) | 有效域名: $SuccessCount    " -ForegroundColor Yellow
    Start-Sleep -Milliseconds 50
}

if ($FinalResults.Count -gt 0) {
    Write-Host "`n全部测试完成，正在对 $SuccessCount 条有效数据按延迟排序并取前 $ResultLimit 条..." -ForegroundColor Cyan
    $SortedList = $FinalResults | Sort-Object { [int]$_.time } | Select-Object -First $ResultLimit
    $OutputBuffer = New-Object System.Collections.Generic.List[string]
    foreach ($item in $SortedList) {
        $OutputBuffer.Add("$($item.domain):443#$($item.domain)")
    }
    [System.IO.File]::WriteAllLines($AbsBestOutput, $OutputBuffer, $Utf8NoBom)
}

$Pool.Close(); $Pool.Dispose()
Write-Host "`n已保存至: $BestOutputFile" -ForegroundColor Green