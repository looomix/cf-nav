@echo off
chcp 65001 >nul

powershell -NoProfile -ExecutionPolicy Bypass -File "CheckDomains.ps1"
pause