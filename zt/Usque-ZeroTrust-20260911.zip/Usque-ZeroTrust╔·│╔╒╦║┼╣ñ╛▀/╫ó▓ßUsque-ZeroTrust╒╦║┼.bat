usque.exe register --jwt 删除这里的中文替换成你的token

pause
